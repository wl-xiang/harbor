// Copyright Project Harbor Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
import {
    ComponentFixture,
    TestBed,
    fakeAsync,
    tick,
} from '@angular/core/testing';
import { ProjectAuditLogComponent } from './audit-log.component';
import { MessageHandlerService } from '../../../shared/services/message-handler.service';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA, LOCALE_ID } from '@angular/core';
import { delay } from 'rxjs/operators';
import { AuditLogExt } from '../../../../../ng-swagger-gen/models/audit-log-ext';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { ProjectService } from '../../../../../ng-swagger-gen/services/project.service';
import { SharedTestingModule } from '../../../shared/shared.module';
import { registerLocaleData } from '@angular/common';
import locale_en from '@angular/common/locales/en';
import { DatePickerComponent } from '../../../shared/components/datetime-picker/datetime-picker.component';

describe('ProjectAuditLogComponent', () => {
    let component: ProjectAuditLogComponent;
    let fixture: ComponentFixture<ProjectAuditLogComponent>;
    const mockMessageHandlerService = {
        handleError: () => {},
    };
    const mockActivatedRoute = {
        parent: {
            parent: {
                parent: {
                    snapshot: {
                        data: null,
                    },
                },
            },
        },
        snapshot: {
            data: null,
        },
        data: of({
            auditLogResolver: '',
        }).pipe(delay(0)),
    };
    const mockRouter = null;
    const mockedAuditLogExts: AuditLogExt[] = [];
    for (let i = 0; i < 18; i++) {
        let item: AuditLogExt = {
            id: 234 + i,
            resource: 'myProject/Demo' + i,
            resource_type: 'N/A',
            operation: 'create',
            op_time: '2017-04-11T10:26:22Z',
            username: 'user91' + i,
        };
        mockedAuditLogExts.push(item);
    }
    const fakedAuditlogExtService = {
        getLogExtsResponse(params: ProjectService.GetLogsParams) {
            if (params.q && params.q.indexOf('Demo0') !== -1) {
                return of(
                    new HttpResponse({
                        body: mockedAuditLogExts.slice(0, 1),
                        headers: new HttpHeaders({
                            'x-total-count': '18',
                        }),
                    })
                ).pipe(delay(0));
            }
            if (params.page <= 1) {
                return of(
                    new HttpResponse({
                        body: mockedAuditLogExts.slice(0, 15),
                        headers: new HttpHeaders({
                            'x-total-count': '18',
                        }),
                    })
                ).pipe(delay(0));
            } else {
                return of(
                    new HttpResponse({
                        body: mockedAuditLogExts.slice(15),
                        headers: new HttpHeaders({
                            'x-total-count': '18',
                        }),
                    })
                ).pipe(delay(0));
            }
        },
    };
    registerLocaleData(locale_en, 'en-us');
    beforeEach(async () => {
        TestBed.overrideComponent(DatePickerComponent, {
            set: {
                providers: [
                    {
                        provide: LOCALE_ID,
                        useValue: 'en-us',
                    },
                ],
            },
        });
        await TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            imports: [SharedTestingModule],
            declarations: [ProjectAuditLogComponent],
            providers: [
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                { provide: Router, useValue: mockRouter },
                { provide: ProjectService, useValue: fakedAuditlogExtService },
                {
                    provide: MessageHandlerService,
                    useValue: mockMessageHandlerService,
                },
            ],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ProjectAuditLogComponent);
        component = fixture.componentInstance;
        component.projectName = 'test-project';
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('should get data from AccessLogService', async () => {
        fixture.detectChanges();
        await fixture.whenStable();
        fixture.detectChanges();
        await fixture.whenStable();
        expect(component.auditLogs).toBeTruthy();
        expect(component.auditLogs.length).toEqual(15);
    });

    it('should render data to view', async () => {
        fixture.detectChanges();
        await fixture.whenStable();
        fixture.detectChanges();
        await fixture.whenStable();

        expect(component.auditLogs.length).toBeGreaterThan(0);
        expect(component.auditLogs[0].username).toEqual('user910');
    });
    it('should support pagination', async () => {
        component.projectName = 'test-project';
        component.pageSize = 15;
        fixture.autoDetectChanges(true);
        await fixture.whenStable();
        // Pagination controls are only rendered when page.last > 1; wait for data to load
        let attempts = 0;
        while (component.totalRecordCount === 0 && attempts < 50) {
            await new Promise(resolve => setTimeout(resolve, 10));
            fixture.detectChanges();
            attempts++;
        }
        expect(component.totalRecordCount).toBe(18);
        fixture.detectChanges();
        const el: HTMLButtonElement =
            fixture.nativeElement.querySelector('.pagination-next');
        expect(el).toBeTruthy();
        el.click();
        fixture.detectChanges();
        await fixture.whenStable();
        expect(component.currentPage).toEqual(2);
        expect(component.auditLogs.length).toEqual(3);
    });

    it('should support filtering list by keywords', fakeAsync(() => {
        fixture.detectChanges();
        tick();
        fixture.detectChanges();
        tick();
        component.doSearchAuditLogs('Demo0');
        fixture.detectChanges();
        tick();
        fixture.detectChanges();
        tick();
        expect(component.auditLogs).toBeTruthy();
        expect(component.auditLogs.length).toEqual(1);
    }));
});
